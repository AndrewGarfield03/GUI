package com.company;

public class TooManyThingsException extends Exception{
    public TooManyThingsException(String message) {
        super(message);
    }
}
