package com.company;

public class ProblematicTenantException extends Exception{
    public ProblematicTenantException(String message) {
        super(message);
    }
}
